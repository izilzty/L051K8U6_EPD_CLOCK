
file = open('original.txt', mode='r', encoding='utf-8')
file_new = open('new.txt', mode='w', encoding='utf-8')


total = 0
final = 0
while (True):
    single_pack = ""
    charter = ""
    while (True):
        single_pack = single_pack + file.readline()
        if (single_pack == ""):
            final = 1
            break
        if (single_pack.find("/") != -1):
            charter = single_pack[single_pack.find("/")+3:single_pack.find("/")+4]
            single_pack = single_pack[:single_pack.find("/")]
            file.readline()
            file.readline()
            break
    if (final == 1):
        break

    list_of_bytes = ord(charter).to_bytes(3, 'big')

    file_new.write("0x" + hex(list_of_bytes[0])[2:].zfill(2).upper()+", ")
    file_new.write("0x" + hex(list_of_bytes[1])[2:].zfill(2).upper()+", ")
    file_new.write("0x" + hex(list_of_bytes[2])[2:].zfill(2).upper() + ",")
    file_new.write(" /* UNICODE索引 - "+charter+" */\n")
    file_new.write(single_pack)
    file_new.write("\n")
    total = total + 1

print("总字符数："+str(total))

file.close()
file_new.close()
