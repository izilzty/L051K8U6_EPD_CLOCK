
file = open('original.txt', mode='r', encoding='utf-8')

total = 0
final = 0
single_pack = ""
charter = ""
while (True):
    while (True):
        single_pack = file.readline()
        if (single_pack == ""):
            final = 1
            break
        if (single_pack.find("/") != -1):
            charter = charter + single_pack[single_pack.find("/") + 15:single_pack.find("/") + 16]
            total = total + 1
            break
    if (final == 1):
        break

print("总字符数：" + str(total))
print("读取到的字符: " + charter)

file.close()
