
This font is Cardware, please send a Post Card to me as thanks for
my time used to save you lots of time, tell me about you or your
company or where you live on the card. Sure send money if you like too :)

Also if I knock your door, I will expect a free beer ;).

	Darren Moore
	Mooretronics 
	10 Wilga Street
	Mt Waverley Vic 3149
	AUSTRALIA

	mooretronics@gmail.com

Directions, install the font file in your fonts folder, then use the
font from any True Type font list named Mooretronics.

Note: If you send you pcb file to someone, you will need to either
Embed the font, or send them the file, please send this readme file
if you do send the font to others. 

Also I'm _not_ giving permission to post this True Type font on the 
internet. You may pass it on directly though.

Enjoy,
Darren Moore


Used characters:

dec                                     dec
65 A	Attention with text		 97 a	Attention IEC348
66 B					 98 b
67 C	CE				 99 c	Canadian Standards Association
68 D					100 d
69 E	ESD with text			101 e	ESD
70 F	FCC				102 f
71 G	Earth Ground IEC5017		103 g	Frame Ground
72 H	High Voltage IEC60417-1-5036	104 h
73 I					105 i
74 J					106 j
75 K					107 k
76 L					108 l
77 M					109 m
78 N	Noiseless Earth IEC5018		110 n
79 O	Open Hardware with text		111 o	Open Hardware graphic only
80 P	Pb Free with text		112 p	Pb Free
81 Q					113 q
82 R	RoHS + Tick			114 r	RCM Mark
83 S	Protective Earth IEC5019	115 s
84 T	C-TCK				116 t
85 U	UL				117 u
86 V					118 v
87 W	WEEE				119 w	
88 X					120 x
89 Y					121 y
90 Z					122 z

The IEC numbers might not be exactly as per the standard, but similar.
